# Observed-unit stencil occlusion candidate

Status: SOURCE-ONLY CANDIDATE. No Godot import, fixture, rendered review, gameplay review, mobile/browser timing or visual acceptance has run for this patch. The predecessor's unoccluded off/on fixture failed, with 13,246 altered pixels reported by the independent visual review. Do not carry forward its apparent visual acceptance.

## Chosen method

The original unit materials remain untouched. One identity-transform child MeshInstance3D shares each source mesh and skin, with its skeleton path resolved to the same Skeleton3D, with two globally ordered transparent passes:

1. Priority 110: a zero-alpha, normal-depth-tested, no-depth-write mask writes stencil value 1 at normally visible unit pixels. It runs after the opaque/cutout world. All authorized rigs write the same union mask before any silhouette.
2. Priority 120: a flat team-tinted silhouette reads stencil != 1 and uses inverted hardware depth. It can only color occluded unit fragments and cannot touch any normally visible unit pixel. Alpha is exactly 1 in the transparent queue, so overlapping hidden limbs overwrite the same color instead of accumulating translucency into stripes.

The stencil value 1 and priorities 110/120 are reserved by this effect. No other project shader currently uses stencil. Future stencil effects must coordinate that reservation. This implementation deliberately does not use the built-in opaque STENCIL_MODE_XRAY preset: in Godot 4.6.3 GLES3, any opaque stencil write forces a whole-world depth prepass. Both new passes use ALPHA and depth_draw_never, so they remain alpha-only. No screen/depth sampler, viewport, full-screen pass, raycast, CPU mesh bake, per-frame allocation or bias is introduced.

## Eligibility and assets

The existing FactionView -> observed_character_presenter -> action_character boundary is unchanged. Hidden enemy records release their controller; hidden ancestors hide both passes; remembered units are not candidates; start_death disables the effect. set_authorized(true) now also requires the rig's existing authorization metadata, so it cannot revive a corpse's overlay.

Only the currently normalized opaque, double-sided (cull-disabled) action-rig materials are supported. Both mask and silhouette use exactly that culling. The current four licensed GLBs have doubleSided=true on both materials; other culling fails closed. The child overlay inherits source local transform and visibility changes automatically, including tool-specific animation, and the fixtures exercise this. Mesh resource, skin, skeleton assignment, materials, render layers and range/opacity settings are bind-time contracts: changing those requires rebinding. Expected unsupported inputs report a reason in stats without emitting a warning, preserving the strict hosted log guard. Alpha, shader-deformed, blended-shape, proximity-faded and incompatible depth/stencil materials fail closed without altering the original unit. New character art needs matching mask coverage and fixtures before extending this support. World alpha-scissor foliage works through its ordinary depth coverage. Alpha-blended world geometry that writes no depth is not an occluder. Visible units mutually protect their normal pixels; a far unit does not tint a near visible unit.

The current game uses presentation meshes for trees/buildings and triangle-based resource picking, not a ready-made world-only collision layer. A bounded anchor-ray test could cheaply enable/disable whole units, but cannot prevent coloring self-overlapping limbs when only part of a unit is blocked. A separate world-only depth viewport adds another camera/world render. The transparent stencil route supplies per-pixel identity without either approximation or another world render.

## Cost contract, not measured phone performance

One additional child mesh instance and two unshaded geometry passes per observed rig mesh, sharing all geometry and skin resources. Current rigs have one mesh and two surfaces: maximum four extra surface draws, and up to two extra skinning evaluations. Frustum/ancestor culling stays with the engine. There is no new CPU work per frame and no effect-owned full-screen/depth copy. This costs more local unit geometry than the rejected one-pass overlay and MUST be profiled on the phone target before acceptance.

## Required hosted checks

Run only through the reviewed hosted resource gate, with Godot 4.6.3 Compatibility and the existing clean import/manifest workflow:

- tests/occlusion_stencil_contract.gd: material API, shared geometry, ordered passes, current own/enemy eligibility, remembered/hidden/death release and unsupported-alpha fail-closed checks. It is not a pixel test.
- tests/occlusion_render_fixture.gd: six genuine 390x600 off/on/hidden/reference frames. Exact zero changed pixels for the unobstructed unit; exact zero changes to normally visible fragments in the partially blocked unit; a nonempty single-color hidden silhouette; hidden-ancestor equality to absent reference; measured four-draw increase for the current two-surface rig.
- tests/occlusion_stencil_matrix.gd: all four classes in idle/walk/attack, nonvacuous partial coverage for actual pine/oak/house assets, labeled procedural rock geometry (the current map has no standalone large-rock resource), an explicit full-cover plane with exact complete-unit silhouette coverage, A-to-B-to-A movement and empty-frame stencil-reset checks, a behind-unit object, moving overlapping observed units, animated source mesh transform/visibility, corpse suppression, and 1/12/24-unit draw deltas in a scene containing 40 unrelated world meshes. This exposes accidental global depth-prepass cost.
- Retain the existing action-character/fog/gameplay regression suite, then genuine gameplay captures at normal phone scale. The controlled asset cases are not gameplay screenshots. Mesa draw counts are not physical-phone frame-time evidence.

Frame reports bind shader/source hashes, engine/renderer, PNG hashes and draw counts. Do not relax the exact unoccluded/partially-visible pixel requirements to get a pass. If they fail, this candidate is rejected.

## Primary references inspected

- Godot 4.6 spatial shader modes and stencil transparent-pass restriction: https://docs.godotengine.org/en/4.6/tutorials/shaders/shader_reference/spatial_shader.html
- Exact 4.6.3 GLES3 alpha classification, opaque-stencil prepass trigger, GEQUAL default depth, LESS inverted depth, and stencil writes: https://github.com/godotengine/godot/blob/4.6.3-stable/drivers/gles3/rasterizer_scene_gles3.cpp
- Exact 4.6.3 global priority-before-depth transparent ordering: https://github.com/godotengine/godot/blob/4.6.3-stable/drivers/gles3/rasterizer_scene_gles3.h
- Stencil implementation and Compatibility support: https://github.com/godotengine/godot/pull/80710
- Native viewport draw-counter API: https://docs.godotengine.org/en/4.6/classes/class_viewport.html#class-viewport-method-get-render-info
