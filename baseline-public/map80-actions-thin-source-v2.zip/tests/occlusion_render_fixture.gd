extends SceneTree
## Real rendered isolated rig fixture, not a gameplay screenshot or phone claim.
## Run only in the reviewed hosted native renderer with Xvfb/Mesa Compatibility.
const Controller = preload("res://scripts/action_character.gd")
var world: Node3D
var controller
var camera: Camera3D
var occluder: MeshInstance3D
var checks: Array=[]
var output:="res://reports/occlusion-fixture"
func _initialize(): call_deferred("run")
func require_check(label: String, pass_value: bool, detail={}) -> void:
	checks.append({"name":label,"pass":pass_value,"detail":detail})
	if not pass_value: push_error(label+" "+str(detail))
func capture(label: String) -> Image:
	await process_frame; await process_frame; await RenderingServer.frame_post_draw
	var image:=root.get_texture().get_image()
	var error:=image.save_png(output+"/"+label+".png")
	require_check(label+" framebuffer saved",error==OK)
	return image
func difference(a: Image,b: Image) -> int:
	assert(a.get_size()==b.get_size())
	var count:=0
	for y in a.get_height():
		for x in a.get_width():
			var p:=a.get_pixel(x,y);var q:=b.get_pixel(x,y)
			if absf(p.r-q.r)+absf(p.g-q.g)+absf(p.b-q.b)>.05: count+=1
	return count
func run() -> void:
	DirAccess.make_dir_recursive_absolute(output)
	root.size=Vector2i(390,600)
	world=Node3D.new();root.add_child(world)
	var environment:=WorldEnvironment.new();var settings:=Environment.new()
	settings.background_mode=Environment.BG_COLOR;settings.background_color=Color("373d36")
	settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;settings.ambient_light_energy=.7
	environment.environment=settings;world.add_child(environment)
	var light:=DirectionalLight3D.new();light.rotation_degrees=Vector3(-45,-20,0);world.add_child(light)
	camera=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.size=2.9
	camera.position=Vector3(2,2.2,4);world.add_child(camera);camera.look_at(Vector3(0,.9,0));camera.current=true
	var body:=Node3D.new();world.add_child(body)
	controller=Controller.new();require_check("fixture bound real exported rig",controller.bind(body,"spearman",Color("435d6c")))
	controller._start("idle",.5,false,false)
	controller.occlusion.set_authorized(false);var normal_off:Image=await capture("01-normal-overlay-off")
	controller.occlusion.set_authorized(true);var normal_on:Image=await capture("02-normal-overlay-on")
	require_check("normal visible mesh unchanged",difference(normal_off,normal_on)==0,{"changed_pixels":difference(normal_off,normal_on)})
	occluder=MeshInstance3D.new();var box:=BoxMesh.new();box.size=Vector3(.9,1.5,.35);occluder.mesh=box
	var mat:=StandardMaterial3D.new();mat.albedo_color=Color("665a46");mat.roughness=1;occluder.material_override=mat
	world.add_child(occluder);occluder.position=Vector3(.35,.78,.8)
	controller.occlusion.set_authorized(false);var hidden_off:Image=await capture("03-object-occluded-overlay-off")
	controller.occlusion.set_authorized(true);var hidden_on:Image=await capture("04-object-occluded-overlay-on")
	require_check("occluded authorized unit receives silhouette",difference(hidden_off,hidden_on)>30,{"changed_pixels":difference(hidden_off,hidden_on)})
	body.hide();var fog_hidden:Image=await capture("05-fog-hidden-parent")
	controller.release();var absent:Image=await capture("06-no-unit-reference")
	require_check("hidden ancestor silhouette is absent",difference(fog_hidden,absent)==0,{"changed_pixels":difference(fog_hidden,absent)})
	var failed=checks.filter(func(c):return not c.pass).size()
	var file:=FileAccess.open(output+"/report.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope":"Real native controlled rig/depth fixture, not gameplay or phone acceptance","build":load("res://scripts/rules.gd").BUILD_ID,"checks":checks,"failed":failed,"renderer":RenderingServer.get_current_rendering_method()},"  ")+"\n");file.close()
	world.free();quit(1 if failed else 0)
