# Map80 + licensed skeletal action prototype

Source-only combined candidate. Not deployed, not artistically accepted, and not yet runnable: native character scenes require a guarded hosted Godot import.

- Baseline mobile controls: accepted vc-8fcc302051f0.
- Map source: vc-eb734476b9f1, independently checked hosted run42339914268,507 assertions passed. This pass does not apply to the combined candidate.
- Licensed Blender output: hosted run42339730042, four current classes,25 clips,125 reopened mesh deformation samples. Structural/artifact review passed, not rendered quality.
- The three-way game.gd merge had no conflicts. Only _create_world was changed by both sides; terrain/map changes and ambient/sun settings occupy separate lines. Every other side-specific changed function is byte-preserved.
- Original source/CC0 licenses and editable .blend files are under art/. Keep the verified empty art/.gdignore before any Godot scan.

## Mandatory hosted stage order

1. Verify the closed source lock before execution. Use the approved process/RSS/time/cleanup supervisor, official Godot4.6.3, and no local Blender/Godot run.
2. Clean project import/parse. The ignored art directory must not trigger automatic Blender import.
3. Run tools/import_action_characters.gd to validate reviewed GLB hashes and generate native assets/mature/models/*_action.scn.
4. Run tools/stamp_build.py only now, producing a new runtime identity that includes the native scenes. The inherited BUILD_ID in source is not a valid identity for this combined build. Rebind every following report/command to the generated identity and exact native scene hashes.
5. Run the12 map suites, smoke/regression contracts and tests/action_characters.gd. Combined runtime/authority acceptance has not happened yet.
6. Use the reviewed native renderer for tests/action_render_fixture.gd, tests/occlusion_render_fixture.gd and genuine game captures. The action fixture captures25 three-pose studies with attack/death first, each image bound to actual skeleton and source hashes. Label controlled fixtures separately from gameplay screenshots. Render attack/contact, hit/death and own/observed-enemy/fog-hidden cases early.

Military equipment penetrates below ground in current death clips: spear−1.481m, sword−0.543m, bow−0.348m. Lesser body-ground intersections also need review. Attack impact markers, hand grips, atlas seams and occlusion self-overlap remain provisional. These structural assets are a prototype for rendered correction, not finished art. Physical-phone performance and user visual acceptance remain separate gates.

No main/live source or deployment was changed by this integration.
