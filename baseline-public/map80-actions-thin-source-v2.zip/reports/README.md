# Combined runtime evidence status

This combined source has not been imported, run, rendered or exported. No combined runtime PASS report exists.

map-input-build-manifest.json describes the separately tested Map80 input only. Its vc-eb734476b9f1 identity is not the combined runtime identity. The new build-manifest.json must be generated after hosted native character-scene conversion and must bind every subsequent test/render result.

asset_manifest.json and action-asset-stage.json bind the reviewed Blender source assets. They prove structural/deformation provenance, not Godot or artistic acceptance. Native scenes are deliberately absent until guarded conversion succeeds.

Godot/font notices remain included. Original character source licenses are retained under art/action_characters/licenses. No new public license for original game code/art/audio is granted.
