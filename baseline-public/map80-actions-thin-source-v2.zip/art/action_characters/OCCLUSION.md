# Observed-unit occlusion prototype

Official reference checked: https://docs.godotengine.org/en/stable/tutorials/shaders/advanced_postprocessing.html and https://docs.godotengine.org/en/stable/tutorials/shaders/shader_reference/spatial_shader.html . The former specifies current-viewport depth access and Compatibility OpenGL NDC reconstruction; the latter documents fragment view-space VERTEX and depth modes.

Implementation: one sibling skinned mesh instance shares the rig's exact mesh, skin and Skeleton3D path. An unshaded, no-depth-write, no-shadow transparent overlay reconstructs scene depth and discards normally visible front fragments. Only current observed presenter rigs receive it. Hidden records destroy the rig; a hidden ancestor hides the overlay; witnessed corpses disable it. No hidden enemy authority is submitted to the GPU.

Proposed cost: up to two additional surface draws and one more skinning pass per observed unit, one depth sample per covered fragment; no additional viewport, geometry copy, raycast, screen-wide postprocess or per-frame mesh creation. This is an explicit cost estimate, not measured phone performance.

Important technical limitation: ordinary scene depth lacks object identity. Self-overlapping arms/weapons can count as an occluder; the0.08m bias and backface culling reduce but do not prove absence of artifacts. Transparent objects without a depth prepass cannot occlude this way. A strict normal-mesh-unchanged rendered fixture must pass before adoption, followed by actual tree/building/rock and military-attack poses. If it fails, do not weaken the fixture or silently ship; reconsider mask/stencil or targeted depth strategy and measure its cost.

`tests/occlusion_render_fixture.gd` captures untouched native viewport PNGs with overlay off/on, a controlled opaque occluder, a hidden ancestor and an absent reference. These are explicitly controlled in-engine rig fixtures, not normal gameplay screenshots or physical-phone proof. It has NOT RUN. Actual faction-fog, tree/building/rock screenshots and performance remain required.
