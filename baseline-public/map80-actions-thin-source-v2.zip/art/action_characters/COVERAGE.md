# Current phone-demo character coverage

Status: Blender generation, GLB structural validation and reopened deformation passed for all four classes (25 clips,125 sampled meshes) in hosted run42339730042. Source assets staged only; Godot native/runtime/rendered checks NOT RUN. No runtime art has been promoted. The original procedural fallback recipe is intentionally unexecuted and superseded by the free-asset research direction.

| Live class | Vetted art candidate | Normalized actions required | Motion source / remaining authoring | Actual runtime proof |
|---|---|---|---|---|
| Villager | Quaternius free male Peasant + compatible head | idle, walk, carry_walk, gather_wood, gather_food, build, repair, attack, hit, death | UAL1/2 idle/walk/carry/tree chop/harvest/hit/death; KayKit hammer; separate attack | NOT RUN |
| Spearman | Quaternius Peasant with field equipment | idle, walk, attack, hit, death | UAL idle/walk/hit/death; KayKit two-hand stab retarget; original spear/shield fittings | NOT RUN |
| Archer | Quaternius free male Ranger | idle, walk, attack, hit, death | UAL idle/walk/hit/death; KayKit draw+release retarget and bow hand contacts | NOT RUN |
| Scout | Quaternius free male Ranger | idle, walk, attack, hit, death | UAL sword attack/idle/walk/hit/death, light travel equipment | NOT RUN |

These are four current demo classes, not six implemented classes, a complete historical roster, or future civilization-exclusive armies. Civilization design and broader content remain deferred.

## Asset pipeline requirements

Outfit source GLTFs are headless and carry 65 joints. Peasant has ~12.9k source triangles and Ranger ~27k. A compatible base head must be combined without hidden duplicate body geometry. UAL1/2 use matching names but differing bone-rest offsets/rotations, so direct action assignment is unsafe. Blender must retarget rotation deltas, preserve target proportions, remove root motion and bake actual keyframes. KayKit uses a different 23-bone hierarchy and needs an explicit mapping for bow/hammer/stab.

A 6,500-triangle / 32-bone maximum is a proposed first mobile LOD cap, not measured performance acceptance. One skinned mesh and two material surfaces remain the target; atlas texture downsampling/packing must preserve source detail. Decimation needs silhouette and hand/contact review. Rigid props must attach to the authored hand pose and use per-action visibility, not hover independently.

## Runtime contract prepared

All classes use manual sampled skeletal playback, not whole-body bob. Attack contacts start at the actual successful authority release tick; anticipation uses only a recent observed attack cycle. Damage remains immediate, ledger-owned and exactly once. Hit uses actual positive damage; death creates bounded presentation-only nodes, never authority entities or navigation occupancy. Work cues are emitted only after real successful work ticks. Hidden actor cue history is removed before reappearance. Pause/focus holds playback; final witnessed death visuals may finish after terminal game-over, without running simulation.

Occlusion now has a current-observation-only skinned depth overlay prototype and rendered fixture. No remembered actor or fog-hidden enemy is eligible. It has NOT RUN; self-occlusion artifacts, transparency and phone cost remain gates.

## Required evidence

1. Pinned Blender stage: input hashes/licenses, editable .blend, weights, armature modifiers, keyed bone paths, triangle/material budgets, reopened mesh deformation sampled per class/action, exported GLB skins/channels.
2. Godot native stage: each class/action changes appropriate actual bones, correct contact marker/weapon grip, no gameplay tracks/root motion/collision nodes, own/enemy material independence, pause/cancel/restart/death/fog lifecycle, deterministic authority comparison.
3. Genuine rendered game evidence: portrait and landscape overview, close unit contact sheet/short sequence, real woodcut/harvest/build/repair, three military attacks, hit/death, and occlusion cases once implemented.
4. User visual acceptance and physical-phone performance are separate remaining gates.

## Actual generated structural evidence

- Villager:5,201triangles,26bones,10clips.
- Spearman:5,069triangles,25bones,5clips.
- Archer:5,420triangles,24bones,5clips.
- Scout:5,068triangles,24bones,5clips.

All four use one skinned mesh, two material surfaces and one embedded1024atlas. All25 clips produced changing evaluated geometry in five sampled phases. These are real hosted Blender results, not in-game screenshots. Military death bounds extend below the ground (spearman−1.481m, scout−0.543m, archer−0.348m), likely equipment penetration; render/contact correction remains mandatory.
