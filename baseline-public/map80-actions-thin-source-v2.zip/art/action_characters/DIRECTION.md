# Current status: licensed-art prototype, not accepted visual result

The initial custom geometry direction below is historical. Latest user instruction requires researched free assets rather than independently reinvented primitive characters. `create_action_characters.py` is an unexecuted fallback and MUST NOT be used by the current CI plan.

The active pipeline uses vetted CC0 Quaternius free Standard Peasant/Ranger outfits, compatible base head and hair, UAL1/2 motion plus KayKit specific actions. See COVERAGE.md and the closed prepared-input manifest. Only the four current demo classes are in scope. The licensed assembly/LOD/retarget recipe is still an unrendered prototype awaiting hosted Blender and Godot evidence. Inputs/source review alone is not animation/visual acceptance.

# Valley Crown character direction: field-worn river-valley militia

The accepted mobile source (vc-8fcc302051f0) has static characters and whole-body bob/tilt. The prior villager experiment kept the same static art, one generic work loop and no integrated attack. Neither meets the requested articulated, mature art result.

This isolated candidate replaces the four character silhouettes with adult-proportioned, tapered cloth/limb geometry. Small heads, visible bent elbows/knees, heavy boots, leather belts/satchels, muted team surcoats and charcoal iron. Two matte materials per character, original vertex-color variation, no glossy plastic, no outline or cartoon giant weapons. Team color is concentrated on cloth/shields rather than skin or all surfaces.

Blender owns the mesh, weights, skeleton, actions and keyframes. All four units have idle, walk and distinct attack. Villager has loaded walking, axe woodcutting, low reach/hand harvesting, hammer build and repair. Spearman braces and thrusts; scout steps into a short blade slash; archer plants, draws to the cheek, releases and recovers. Root world position is never animated. Mobile budget: one skinned mesh, two surfaces, under 4,500 triangles and 24 bones each. No runtime IK or per-frame procedural limb generation.

World direction: cool restrained ambient fill and warm directional sun, matte surfaces, dry olive grass/warm earth from the map worker. Building geometry needs separate visual assessment; this change only normalizes material sheen.

Verification separates (1) Blender geometry/weights/action provenance, (2) Godot import/runtime bone pose + observation/authority contracts, (3) genuine in-engine screenshots/motion of gameplay, and (4) user visual acceptance. None of these alone establishes the others. No preview has yet been rendered for this candidate.
