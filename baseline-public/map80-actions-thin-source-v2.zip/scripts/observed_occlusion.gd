extends RefCounted
## Compatibility-safe prototype. No entity/target access, no extra viewport.
const SHADER = preload("res://assets/mature/shaders/observed_occlusion.gdshader")
var overlays: Array[MeshInstance3D] = []
var material: ShaderMaterial
var enabled := true

func bind(rig: Node3D, team_color: Color) -> void:
	assert(rig.get_meta("occlusion_authorized",false))
	material=ShaderMaterial.new(); material.shader=SHADER; material.render_priority=120
	var tint:=team_color.lightened(.55); tint.a=.62
	material.set_shader_parameter("silhouette_color",tint)
	# Sibling instances retain the exact mesh/skin/Skeleton3D relative path.
	# Geometry resources are shared, never copied or rebuilt per frame.
	var source_meshes=rig.find_children("*","MeshInstance3D",true,false)
	for mesh: MeshInstance3D in source_meshes:
		if mesh.get_meta("occlusion_overlay",false): continue
		var overlay:=MeshInstance3D.new()
		overlay.name="ObservedOcclusionOnly"
		overlay.mesh=mesh.mesh; overlay.skin=mesh.skin; overlay.skeleton=mesh.skeleton
		overlay.transform=mesh.transform; overlay.layers=mesh.layers
		overlay.material_override=material
		overlay.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		overlay.set_meta("occlusion_overlay",true)
		mesh.get_parent().add_child(overlay); overlays.append(overlay)

func set_authorized(authorized: bool) -> void:
	enabled=authorized
	for overlay in overlays: overlay.visible=authorized

func stats() -> Dictionary:
	var surfaces:=0
	for overlay in overlays: surfaces+=overlay.mesh.get_surface_count()
	return {"authorized":enabled,"overlay_meshes":overlays.size(),"extra_surface_draws_max":surfaces,"depth_samples_per_fragment":1,"extra_viewports":0,"mode":"depth-gated observed-only prototype"}

func release() -> void:
	for overlay in overlays:
		if is_instance_valid(overlay): overlay.free()
	overlays.clear(); material=null
