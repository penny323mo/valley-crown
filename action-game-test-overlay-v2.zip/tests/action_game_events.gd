extends SceneTree
## Synthetic setup, real command/tick/ledger and observation-controller integration.
## Not rendered contact, Web input, physical-phone performance or art acceptance.
const Rules = preload("res://scripts/rules.gd")
const Controller = preload("res://scripts/action_character.gd")
var g
var checks: Array = []
var combat_cases: Array = []
var fog_cases: Array = []
var death_fog_cases: Array = []
var movement_cases: Array = []
var work_cases: Array = []

func _initialize(): call_deferred("run")

func check(label: String, ok: bool, detail = {}) -> void:
	checks.append({"name":label,"pass":ok,"detail":detail})
	print(("PASS " if ok else "FAIL ")+label+" "+JSON.stringify(detail))

func reset() -> void:
	g._test_reset(); g.set_process(false)
	await process_frame
	g._update_visuals(0.0)

func publish() -> void:
	g._navigation_rebuild(); g._update_vision(); g._update_visuals(0.0)

func tick() -> void:
	g._tick(Rules.TICK); g._update_visuals(0.0)

func advance_pose() -> void:
	g._update_visuals(Rules.TICK)

func issue(attacker: Dictionary, target: Dictionary, team: int = 0) -> void:
	g._submit("order",{"ids":[attacker.id],"target":target.id,"position":target.pos},team)

func controller(id: int):
	return g.character_presenter.controllers.get(id)

func authority_hash() -> String:
	var entities: Array = []
	for ent in g.entities:
		var row = ent.duplicate(true)
		for name in ["node","body","ring","bar","bar_fill","anim"]: row.erase(name)
		entities.append(row)
	return JSON.stringify({"entities":entities,"tick":g.tick_count,"rng":g.rng.state,
		"combat":g._combat_snapshot(),"economy":g.economy.snapshot(),
		"pending_damage":g.pending_damage,"navigation_version":g.navigation_version}).sha256_text()

func damage_to(kind: String, target_kind: String) -> int:
	return maxi(1,Rules.DAMAGE[kind]+(3 if kind=="archer" and target_kind=="spearman" else 0)-Rules.ARMOR.get(target_kind,0))

func combat_case(kind: String) -> void:
	await reset()
	var attacker = g._spawn(kind,0,Vector3(-8.5,0,-8.5))
	publish()
	# Real ground command, path scheduling and measured displacement drive walk.
	var start: Vector3 = attacker.pos
	g._submit("order",{"ids":[attacker.id],"position":start+Vector3(2,0,0)},0)
	var walked = false; var walk_poses: Array = []
	for i in 100:
		tick(); advance_pose()
		var c = controller(attacker.id)
		if c!=null and c.clip=="walk" and c.walk_rate>0 and attacker.pos.distance_to(start)>.01:
			walked=true; walk_poses.append(c.visual_evidence_snapshot().pose_sha256)
		if walk_poses.size()>=3: break
	check(kind+" actual move command drives articulated walk",walked and walk_poses.size()>=3 and walk_poses[0]!=walk_poses[-1])
	movement_cases.append({"kind":kind,"moved_metres":attacker.pos.distance_to(start),"pose_hashes":walk_poses})
	g._set_stance(attacker,"STOP")
	var target = g._spawn(kind,1,attacker.pos+Vector3(1,0,0))
	g._set_stance(target,"STOP")
	var damage = damage_to(kind,kind)
	target.hp=damage*2 # Explicit prior-wound fixture; damage itself remains ledger-owned.
	publish(); var hp_before: int = target.hp
	var first_id: int = g.attack_ledger.next_attack_id()
	issue(attacker,target); tick()
	var release = g.attack_ledger.event(first_id)
	var first_tick: int = g.tick_count
	var a = controller(attacker.id); var t = controller(target.id)
	check(kind+" accepted order releases once on real tick",not release.is_empty() and release.attacker_id==attacker.id and release.target_id==target.id and release.release_tick==first_tick)
	check(kind+" authoritative damage is exact before presentation",target.hp==hp_before-damage and g.attack_ledger.next_attack_id()==first_id+1)
	check(kind+" release cue seeks provisional marker immediately",a!=null and a.clip=="attack" and a.last_attack_tick==first_tick and is_equal_approx(a.playhead,a.player.get_animation("attack").length*Controller.IMPACT_FRACTION[kind]))
	check(kind+" actual nonlethal hit selects same-class recoil",t!=null and t.clip=="hit" and t.last_hit_tick==first_tick and target.alive)
	var witness = {"kind":kind,"release_tick":first_tick,"attack_id":first_id,"damage":damage,
		"attacker":a.visual_evidence_snapshot() if a!=null else {},"hit_target":t.visual_evidence_snapshot() if t!=null else {}}
	if a!=null:
		var saved_pose = a.visual_evidence_snapshot().pose_sha256; var saved_time: float = a.playhead
		g.paused=true; g._tick(Rules.TICK); g._update_visuals(2.0)
		check(kind+" pause freezes authority and skeletal time",g.tick_count==first_tick and a.playhead==saved_time and a.visual_evidence_snapshot().pose_sha256==saved_pose)
		g.paused=false; g.application_focused=false; g._update_visuals(2.0)
		check(kind+" unfocused presentation holds pose",a.playhead==saved_time and a.visual_evidence_snapshot().pose_sha256==saved_pose)
		g.application_focused=true; advance_pose()
		check(kind+" focus resume discards elapsed backlog",a.playhead==saved_time)
	var before = authority_hash()
	for i in 45: advance_pose()
	check(kind+" repeated rendered-time updates cannot allocate damage",authority_hash()==before and g.attack_ledger.next_attack_id()==first_id+1)
	var early_release = false; var anticipation = false; var second = {}
	for i in Rules.ATTACK_TICKS[kind]:
		var next_id: int = g.attack_ledger.next_attack_id()
		tick()
		for attack_id in range(next_id,g.attack_ledger.next_attack_id()):
			var event = g.attack_ledger.event(attack_id)
			if event.attacker_id==attacker.id:
				early_release=early_release or event.release_tick-first_tick<Rules.ATTACK_TICKS[kind]
				second=event
		var record: Dictionary = g.faction_views[0].get_record(attacker.id)
		if record.get("visual_attack_ready",false):
			anticipation=true
			check(kind+" anticipation is currently observed and in range tick "+str(g.tick_count),g._visible_to(target,0) and target.alive and g._attack_distance(attacker.pos,target)<=Rules.RANGE[kind] and attacker.cooldown_ticks>0)
		if not target.alive: break
		advance_pose()
	check(kind+" cooldown not shortened by animation",not early_release and not second.is_empty() and second.release_tick-first_tick==Rules.ATTACK_TICKS[kind])
	check(kind+" legal anticipation exercised",anticipation)
	check(kind+" actual second damage kills target",not target.alive and target.hp<=0)
	check(kind+" death leaves no controller or navigation blocker",controller(target.id)==null and not g.navigation.is_point_solid(g._cell(target.pos)))
	check(kind+" witnessed same-class death is presentation only",g.character_presenter.corpses.size()==1 and g.character_presenter.corpses[0].controller.kind==kind and g.character_presenter.corpses[0].controller.dead and not g.character_presenter.corpses[0].controller.occlusion.enabled)
	if not g.character_presenter.corpses.is_empty():
		witness.death=g.character_presenter.corpses[0].controller.visual_evidence_snapshot()
		var count: int = g.entities.size(); var dead_authority = authority_hash()
		for i in 40: advance_pose()
		check(kind+" corpse expires without authority mutation",g.character_presenter.corpses.is_empty() and g.entities.size()==count and authority_hash()==dead_authority)
	combat_cases.append(witness)

func fog_case(kind: String) -> void:
	await reset()
	var own = g._spawn(kind,0,Vector3(-8.5,0,-8.5))
	var enemy = g._spawn(kind,1,Vector3(-7.5,0,-8.5))
	publish(); issue(own,enemy); tick()
	var old_controller = controller(enemy.id)
	check(kind+" observed enemy rig and occlusion authorized",old_controller!=null and old_controller.occlusion.enabled and old_controller.rig in g.character_presenter.occlusion_candidates())
	var old_rig = old_controller.rig if old_controller!=null else null
	var old_position: Vector3 = enemy.pos
	enemy.pos=Vector3(25,0,-24) # Explicit visibility-boundary fixture relocation.
	g._update_vision(); g._update_visuals(0.0)
	check(kind+" hidden enemy immediately loses rig and cue history",controller(enemy.id)==null and not is_instance_valid(old_rig) and not g.unit_action_cues[0].has(enemy.id))
	check(kind+" hidden enemy absent from snapshots and live records",not g.visual_evidence_snapshot().live.has(str(enemy.id)) and g.faction_views[0].get_record(enemy.id).is_empty())
	check(kind+" own rig remains eligible",controller(own.id)!=null and controller(own.id).rig in g.character_presenter.occlusion_candidates())
	var next_id: int = g.attack_ledger.next_attack_id()
	issue(own,enemy); tick(); advance_pose()
	check(kind+" hidden target command cannot create attack",g.attack_ledger.next_attack_id()==next_id)
	for i in 3: tick(); advance_pose()
	enemy.pos=old_position; g._update_vision(); g._update_visuals(0.0)
	var fresh = controller(enemy.id)
	check(kind+" reappearing enemy does not replay prior hit",fresh!=null and fresh.clip=="idle" and fresh.last_hit_tick==-1 and fresh.last_attack_tick==-1)
	fog_cases.append({"kind":kind,"hidden_id":enemy.id,"reappeared":fresh.visual_evidence_snapshot() if fresh!=null else {}})

func death_fog_case(kind: String) -> void:
	await reset()
	var own = g._spawn(kind,0,Vector3(-8.5,0,-8.5))
	var enemy = g._spawn(kind,1,Vector3(-7.5,0,-8.5))
	own.hp=1; enemy.hp=1 # Prior wounds, not modified attack damage or timing.
	publish(); issue(own,enemy,0); issue(enemy,own,1); tick()
	check(kind+" simultaneous real releases kill both observers",not own.alive and not enemy.alive and g.character_presenter.corpses.size()==2)
	var corpse_cell: int = g._cell_index(enemy.pos)
	tick()
	var teams: Array = []
	for corpse in g.character_presenter.corpses: teams.append(corpse.team)
	check(kind+" next vision tick removes enemy corpse silhouette",g.visible_cells[0][corpse_cell]==0 and teams==[0])
	death_fog_cases.append({"kind":kind,"remaining_teams":teams,"actual_visibility":g.visible_cells[0][corpse_cell]})

func gather_case(resource: String, clip: String) -> void:
	await reset()
	var worker = g._first(0,"villager")
	var target = g._nearest_resource(worker.pos,resource,0)
	check(resource+" normal opening target exists",not target.is_empty())
	if target.is_empty(): return
	issue(worker,target)
	var applied = false; var carrying = false; var work_pose = {}; var carry_pose = {}
	for i in 900:
		tick(); advance_pose()
		var record: Dictionary = g.faction_views[0].get_record(worker.id)
		var c = controller(worker.id)
		if g.economy.worker_view(worker.id).last_gather_tick==g.tick_count:
			applied=applied or (record.get("visual_action","")==clip and c!=null and c.clip==clip)
			if applied and work_pose.is_empty(): work_pose=c.visual_evidence_snapshot()
		if g._cargo_amount(worker)>0 and c!=null and c.clip=="carry_walk" and c.walk_rate>0:
			carrying=true
			if carry_pose.is_empty(): carry_pose=c.visual_evidence_snapshot()
		if g.delivered_total[0]>0: break
		if i%40==0: await process_frame
	check(resource+" applied ledger work drives correct clip",applied)
	check(resource+" loaded real travel drives carry walk",carrying)
	check(resource+" normal cycle actually deposits",g.delivered_total[0]>0 and g.economy.audit().ok)
	work_cases.append({"action":clip,"work":work_pose,"carry":carry_pose,"delivered":g.delivered_total[0]})

func build_repair_case() -> void:
	await reset()
	var worker = g._first(0,"villager"); var plot = Vector3.INF
	for point in g.MapRoutes.build_plots(0,2):
		if g._placement_reason("house",point,0,worker.id).is_empty(): plot=point; break
	check("real construction site available",plot!=Vector3.INF)
	if plot==Vector3.INF: return
	var wood_before: int = g.economy.bank_milli(0).wood
	g._submit("build",{"kind":"house","position":plot,"builder":worker.id},0)
	var build_seen = false; var site = {}; var previous_ticks = 0; var build_pose = {}
	var build_samples: Array = []
	for i in 900:
		tick(); advance_pose(); site=g._first(0,"house")
		if not site.is_empty():
			var c = controller(worker.id)
			if site.build_ticks>previous_ticks and c!=null and c.clip=="build":
				build_seen=true
				if build_pose.is_empty(): build_pose=c.visual_evidence_snapshot()
			# Bounded diagnostic evidence for the preserved build-clip assertion.
			# A nonempty queued path is not proof of current displacement or work.
			if site.build_ticks>previous_ticks and (build_samples.size()<4 or site.build_ticks%40==0 or site.built):
				var record: Dictionary = g.faction_views[0].get_record(worker.id)
				var cue: Dictionary = g.unit_action_cues[0].get(worker.id,{})
				var adjacent: Vector3 = g._free_adjacent(site,worker.pos,false,worker.team,worker)
				build_samples.append({"tick":g.tick_count,"build_ticks":site.build_ticks,"built":site.built,
					"worker_state":worker.state,"path_points":worker.path.size(),"position":str(worker.pos),
					"adjacent_distance":worker.pos.distance_to(adjacent) if adjacent!=Vector3.INF else -1.0,
					"cue_work_tick":cue.get("work_tick",-1),"cue_work_clip":cue.get("work_clip",""),
					"visual_action":record.get("visual_action",""),"visual_moving":record.get("visual_moving",false),
					"clip":c.clip if c!=null else "MISSING","walk_rate":c.walk_rate if c!=null else -1.0})
			previous_ticks=site.build_ticks
			if site.built: break
		if i%40==0: await process_frame
	check("paid real construction advances articulated build",build_seen and not site.is_empty() and site.built and g.economy.bank_milli(0).wood==wood_before-Rules.COSTS.house.wood*1000,
		{"build_clip_seen":build_seen,"site_exists":not site.is_empty(),"site_built":site.get("built",false),
		"wood_before":wood_before,"wood_after":g.economy.bank_milli(0).wood,"expected_wood_after":wood_before-Rules.COSTS.house.wood*1000,"samples":build_samples})
	work_cases.append({"action":"build","pose":build_pose,"site_id":site.get("id",-1),"samples":build_samples})
	if site.is_empty() or not site.built: return
	site.hp-=10; site.last_damage_tick=g.tick_count-100 # Old wound fixture beyond five-second repair lockout.
	var damaged_hp: int = site.hp; var repair_wood: int = g.economy.bank_milli(0).wood
	issue(worker,site)
	var repair_seen = false; var repair_pose = {}
	for i in 100:
		tick(); advance_pose()
		var c = controller(worker.id)
		if worker.last_repair_tick==g.tick_count and c!=null and c.clip=="repair":
			repair_seen=true
			if repair_pose.is_empty(): repair_pose=c.visual_evidence_snapshot()
		if site.hp==site.max_hp: break
	check("actual repair work drives repair clip and payment",repair_seen and site.hp>damaged_hp and g.economy.bank_milli(0).wood<repair_wood and g.economy.audit().ok)
	work_cases.append({"action":"repair","pose":repair_pose,"healed":site.hp-damaged_hp})

func bounded_cleanup_case() -> void:
	await reset()
	# Twenty own units respects the live population maximum. Direct deaths here
	# stress only the presentation cap; real combat deaths were tested above.
	for i in 14: g._spawn("scout",0,Vector3(-9.5+(i%7),0,-7.5+floori(i/7.0)))
	publish(); var authority_count: int = g.entities.size()
	for ent in g.entities:
		if ent.team==0 and ent.category=="unit" and ent.alive: g._kill(ent)
	g._publish_faction_views(); g._update_visuals(0.0)
	check("bounded synthetic death burst caps at16 without authority additions",g.character_presenter.corpses.size()==16 and g.entities.size()==authority_count)
	var old_nodes: Array = []
	for corpse in g.character_presenter.corpses: old_nodes.append(weakref(corpse.node))
	g._test_reset(); await process_frame
	var freed = true
	for ref in old_nodes: freed=freed and ref.get_ref()==null
	check("restart frees corpses rigs and event history",freed and g.character_presenter.corpses.is_empty() and g.character_presenter.controllers.is_empty() and g.pending_visual_deaths.is_empty() and g.unit_action_cues==[{},{}])

func run() -> void:
	var args = OS.get_cmdline_user_args()
	if args.size()!=1: push_error("Provide one output JSON path"); quit(2); return
	g=load("res://main.tscn").instantiate(); root.add_child(g); g.test_mode=true; g.set_process(false)
	for kind in Controller.KINDS:
		await combat_case(kind); await fog_case(kind); await death_fog_case(kind)
	await gather_case("food","gather_food"); await gather_case("wood","gather_wood")
	await build_repair_case(); await bounded_cleanup_case()
	check("all four live classes exercised",combat_cases.size()==4 and movement_cases.size()==4 and fog_cases.size()==4 and death_fog_cases.size()==4)
	check("all applied villager work families exercised",work_cases.size()==4)
	var failed = checks.filter(func(row):return not row.pass).size()
	var report = {"build":Rules.BUILD_ID,"source_sha256":FileAccess.get_sha256("res://scripts/game.gd"),
		"passed":checks.size()-failed,"failed":failed,"checks":checks,"combat_cases":combat_cases,
		"movement_cases":movement_cases,"fog_cases":fog_cases,"death_fog_cases":death_fog_cases,"work_cases":work_cases,
		"scope":"Synthetic initial positions/wounds, real orders and fixed ticks with ledger settlement and observed skeletal presentation. No rendered contact, Web, physical-phone, balance or art acceptance."}
	FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify(report,"  "))
	print("ACTION_GAME_EVENTS ",checks.size()-failed,"/",checks.size())
	g.free(); quit(0 if failed==0 else 1)
