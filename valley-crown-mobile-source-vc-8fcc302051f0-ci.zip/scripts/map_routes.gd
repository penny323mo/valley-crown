class_name PublicMapRoutes
extends RefCounted
## Immutable public map metadata. No entities, faction vision, occupancy,
## search state, or producer lifecycle contributes to the corridor graph.

const MAP_SIZE := 48
const PLAYER_BUILD_PLOTS: Array[Vector3] = [
	Vector3(-15, 0, 9), Vector3(-7, 0, 9), Vector3(-11, 0, 14),
	Vector3(-7, 0, 14), Vector3(-17, 0, 9),
]
# The seeded resource positions use integer world coordinates, which are not
# exact 47-cell mirrors after flooring. Keep these verified faction-specific
# fixed plot anchors instead of discovering plots from runtime hidden state.
const ENEMY_BUILD_PLOTS: Array[Vector3] = [
	Vector3(6, 0, -10), Vector3(11, 0, -15), Vector3(6, 0, -15),
	Vector3(11, 0, -6), Vector3(2, 0, -10),
]


static func corridor_mask() -> Dictionary:
	var mask: Dictionary = {}
	for x in range(5, 25):
		for y in [31, 40]:
			mask[Vector2i(x, y)] = true
			mask[Vector2i(47 - x, 47 - y)] = true
	for y in range(31, 41):
		for x in [5, 19]:
			mask[Vector2i(x, y)] = true
			mask[Vector2i(47 - x, 47 - y)] = true
	for y in range(7, 41):
		mask[Vector2i(24, y)] = true
	mask.make_read_only()
	return mask


static func build_plots(team: int, footprint_width: int) -> Array[Vector3]:
	var plots: Array[Vector3] = []
	var anchors := PLAYER_BUILD_PLOTS if team == 0 else ENEMY_BUILD_PLOTS
	for base in anchors:
		var center := base + (Vector3(0.5, 0, 0.5) if footprint_width % 2 == 1 else Vector3.ZERO)
		plots.append(center)
	return plots
