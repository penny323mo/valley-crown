extends RefCounted
## Narrow work-routing view, NOT a complete FactionView/HUD/AI memory system.
## Receives observed entity snapshots only, never full navigation/world data.
## Visibility matches GameSession._visible_to (entity center), not a partly
## visible footprint. Remembered unseen static footprints remain frozen.
var grid := AStarGrid2D.new()
var revision := 0
var resources: Dictionary = {}
var structures: Dictionary = {}
var known_obstacles: Dictionary = {}
var observed_solids: Dictionary = {}
var own_solids: Dictionary = {}
var resource_observed_at: Dictionary = {}
var obstacle_observed_at: Dictionary = {}
var cell_observed_at: Dictionary = {}
const UNKNOWN_POLICY := "free_except_fixed_public_boundary"

func _init() -> void:
	grid.region = Rect2i(0, 0, 48, 48); grid.update()
	for y in 48:
		for x in 48:
			if x < 2 or y < 2 or x > 45 or y > 45:
				grid.set_point_solid(Vector2i(x, y))

func observe(seen_static: Dictionary, owned: Dictionary, own_cells: Dictionary, tick: int) -> Dictionary:
	var changed := {}
	var records_changed := false
	for id in seen_static:
		var record: Dictionary = seen_static[id]
		obstacle_observed_at[id] = tick
		for cell in record.cells: cell_observed_at[cell] = tick
		if known_obstacles.get(id, {}) != record:
			known_obstacles[id] = record.duplicate(true); records_changed = true
		if record.category == "resource":
			resource_observed_at[id] = tick
			resources[id] = record.duplicate(true)
	if structures != owned:
		structures = owned.duplicate(true); records_changed = true
	own_solids = own_cells.duplicate()
	observed_solids.clear()
	for record in known_obstacles.values():
		if record.alive:
			for cell in record.cells: observed_solids[cell] = true
	for y in 48:
		for x in 48:
			var cell := Vector2i(x, y)
			var solid: bool = x < 2 or y < 2 or x > 45 or y > 45 or observed_solids.has(cell) or own_solids.has(cell)
			if grid.is_point_solid(cell) != solid:
				grid.set_point_solid(cell, solid); changed[cell] = true
	if records_changed or not changed.is_empty(): revision += 1
	return {"cells": changed, "records_changed": records_changed}
