extends Control
var game: Node
func _draw():
	draw_style_box(_box(), Rect2(Vector2.ZERO, size))
	if not is_instance_valid(game): return
	var area = Rect2(Vector2(9,9), size-Vector2(18,18))
	draw_rect(area, Color("4f6550"))
	for e in game.faction_views[0].records().values():
		var p = Vector2((e.pos.x+24)/48.0, (e.pos.z+24)/48.0)*area.size+area.position
		var col = Color("d8c067") if e.team==0 else Color("e07762")
		if e.team==-1:
			col=Color("b7ac64") if e.kind=="gold" else Color("90aa64")
		if e.remembered: col=Color("777b79")
		var r=3.3 if e.category=="building" else 1.7
		draw_circle(p,r,col)
	var cp=Vector2((game.camera_focus.x+24)/48.0,(game.camera_focus.z+24)/48.0)*area.size+area.position
	draw_rect(Rect2(cp-Vector2(37,25),Vector2(74,50)),Color(1,0.96,0.78,0.7),false,1.0)
func _gui_input(event):
	if (event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT) or (event is InputEventScreenTouch and event.pressed):
		var uv=(event.position-Vector2(9,9))/(size-Vector2(18,18))
		game.camera_focus=Vector3(clampf(uv.x*48-24,-20,20),0,clampf(uv.y*48-24,-20,20))
		accept_event()
func _box():
	var b=StyleBoxFlat.new()
	b.bg_color=Color("172b2b")
	b.border_color=Color("837951")
	b.set_border_width_all(1)
	b.set_corner_radius_all(7)
	return b
