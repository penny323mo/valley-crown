# Valley & Crown

A small original medieval real-time strategy game built with Godot 4.6.3.

## Controls

Select a worker or unit, press **指令**, then tap a resource or destination. **取消** leaves targeting. Building placement uses a preview followed by **確認建造**. Building choices and secondary actions scroll horizontally. Two fingers pan and zoom the battlefield.

## Reproducible native checks

Use the official Godot 4.6.3 Linux x86_64 binary and matching export templates. The test runner verifies the engine binary and the runtime manifest in `tools/source_manifest.json`.

1. Import the project with `godot --headless --editor --path . --import`.
2. Run `python3 tools/run_phone_checks.py --godot godot`.
3. Retain `artifacts/tests/`, including per-suite logs, JSON reports and partial progress journals on failures.
4. Export the Web preset only after checks pass: `godot --headless --path . --export-release Web dist/index.html`.

The core-flow suite uses routed physical-coordinate synthetic touch events at portrait and landscape sizes, with DPR1/2/3 presentation fixtures. It checks explicit targeting, food and wood gathering/deposit, all four building previews, cancellation, and paid house/barracks completion. Additional suites cover resource geometry, held previews, selection and interrupted input. Native tests do not establish browser or physical-phone acceptance.

## Notices

Font license notices are included under `assets/fonts/`. `GODOT-LICENSES.txt` contains the engine's bundled notices. The runtime art and game code are original project assets.
