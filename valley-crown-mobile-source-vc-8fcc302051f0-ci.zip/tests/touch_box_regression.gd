extends SceneTree
# Routed native synthetic ScreenTouch/ScreenDrag tests. Not phone/browser evidence.
var g
var rows=[]
var lo=Vector2(270,400)
var hi=Vector2(410,500)
func _initialize():call_deferred("run")
func check(label,ok,detail={}):
 rows.append({"name":label,"pass":bool(ok),"detail":detail});print("CHECK ",label," ",ok," ",detail)
func settle(n=4):
 for i in n:await process_frame
func touch(point,down,index=0,canceled=false):
 var e=InputEventScreenTouch.new();e.position=point;e.index=index;e.pressed=down;e.canceled=canceled;root.push_input(e,true)
func drag(a,b,index=0):
 var e=InputEventScreenDrag.new();e.position=b;e.relative=b-a;e.index=index;root.push_input(e,true)
func mouse(point,down,button=MOUSE_BUTTON_LEFT):
 var e=InputEventMouseButton.new();e.position=point;e.global_position=point;e.button_index=button;e.pressed=down;root.push_input(e,true)
func motion(a,b):
 var e=InputEventMouseMotion.new();e.position=b;e.global_position=b;e.relative=b-a;root.push_input(e,true)
func key(code):
 var e=InputEventKey.new();e.physical_keycode=code;e.keycode=code;e.pressed=true;root.push_input(e,true);e.pressed=false;root.push_input(e,true)
func find_button(node,label):
 if node is Button and node.text==label:return node
 for child in node.get_children():
  var b=find_button(child,label)
  if b!=null:return b
 return null
func button_touch(button):
 var point=button.get_global_rect().get_center();touch(point,true);touch(point,false);await settle()
func fresh():
 g._test_reset();g._cancel_mode();g.camera_focus=Vector3(-7,0,5);g.camera_zoom=30;g._camera_update();g.compact_menu.hide();g.compact_menu_dismiss.hide();g._select([g._first(0,"scout").id]);g._update_hud();await settle()
 var focus=root.gui_get_focus_owner()
 if is_instance_valid(focus):focus.release_focus()
func start():
 g._start_box_select();await settle()
func path():
 touch(lo,true);drag(lo,hi)
func finish():touch(hi,false);await settle()
func same_selection():return g.selected==[g._first(0,"scout").id]
func no_gameplay():return g.commands.is_empty() and g.command_sequence==0 and g.tick_count==0 and g.stocks[0].food==150 and g.stocks[0].wood==200
func selection_is(ids):
 var got=g.selected.duplicate();got.sort();var want=ids.duplicate();want.sort();return got==want
func run():
 root.size=Vector2i(1180,812);g=load("res://main.tscn").instantiate();root.add_child(g);g.test_mode=true;g.set_process(false);await settle()
 await fresh();await button_touch(g.compact_menu_button);var b=find_button(g.compact_menu,"框選單位")
 check("menu exposes dedicated 46-pixel mode button",b!=null and b.size.y>=46)
 await button_touch(b)
 check("routed menu touch enters mode without gameplay",g.box_select_mode and not g.compact_menu.visible and not g.compact_menu_dismiss.visible and no_gameplay())
 b=find_button(g.actions,"取消框選")
 check("mode has persistent readable title and cancel",g.selection_title.text=="框選單位" and b!=null and b.is_visible_in_tree() and b.size.y>=46 and not g.compact_unit_tools.visible)
 await button_touch(b);check("routed Cancel preserves selection and clears mode",not g.box_select_mode and same_selection() and no_gameplay())
 for reverse in [false,true]:
  await fresh();await start();var a=hi if reverse else lo;var z=lo if reverse else hi;var camera=g.camera_focus;var zoom=g.camera_zoom
  touch(a,true);drag(a,z);await settle()
  check("routed rectangle visible without pan "+str(reverse),g.drag_rect.visible and g.touch_box_active and g.camera_focus==camera and g.camera_zoom==zoom and same_selection())
  touch(z,false);await settle()
  check("rectangle selects five local workers and exits "+str(reverse),selection_is([1,2,3,4,5]) and not g.box_select_mode and g.touch_box_index==-1 and not g.drag_rect.visible,{"ids":g.selected})
  check("selection is gameplay side-effect-free "+str(reverse),no_gameplay())
  touch(z,false);await settle();check("duplicate release retains selected set "+str(reverse),selection_is([1,2,3,4,5]) and no_gameplay())
 await fresh();await start();touch(lo,true);touch(lo,false);await settle()
 check("tap keeps mode and prior selection",g.box_select_mode and same_selection() and not g.drag_rect.visible)
 touch(lo,true);drag(lo,lo+Vector2(9,0));touch(lo+Vector2(9,0),false);await settle()
 check("subthreshold drag cannot select or pan",g.box_select_mode and same_selection() and g.camera_focus==Vector3(-7,0,5))
 touch(Vector2(650,300),true);drag(Vector2(650,300),Vector2(690,340));touch(Vector2(690,340),false);await settle()
 check("completed empty rectangle clears selection and exits",g.selected.is_empty() and not g.box_select_mode and no_gameplay())
 # Owned units only, regardless of resource/building/enemy projected overlap.
 await fresh();var enemy=g._spawn("spearman",1,Vector3(-13,0,13.5));var dead=g._spawn("spearman",0,Vector3(-12,0,13.5));g._kill(dead);g._update_vision()
 await start();touch(Vector2(260,380),true);drag(Vector2(260,380),Vector2(550,520));touch(Vector2(550,520),false);await settle()
 check("rectangle excludes buildings resources visible enemies and dead units",selection_is([1,2,3,4,5,6]) and not g.selected.has(enemy.id) and not g.selected.has(dead.id),{"ids":g.selected})
 # Every cancellation leaves the previously selected scout intact.
 for interrupt in ["second_world","second_hud","system_cancel","hud_release","escape","right_click","menu","pause","viewport_callback","focus","modal","ended"]:
  await fresh();await start();path();await settle()
  match interrupt:
   "second_world":touch(Vector2(650,350),true,1);touch(Vector2(650,350),false,1)
   "second_hud":touch(g.pause_button.get_global_rect().get_center(),true,1);touch(g.pause_button.get_global_rect().get_center(),false,1)
   "system_cancel":touch(hi,false,0,true)
   "hud_release":touch(g.pause_button.get_global_rect().get_center(),false)
   "escape":key(KEY_ESCAPE)
   "right_click":mouse(hi,true,MOUSE_BUTTON_RIGHT);mouse(hi,false,MOUSE_BUTTON_RIGHT)
   "menu":g._toggle_compact_menu()
   "pause":g._toggle_pause()
   "viewport_callback":g._on_viewport_size_changed()
   "focus":g.test_mode=false;g._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT);g.test_mode=true
   "modal":g._confirm_surrender()
   "ended":g._submit("surrender");g._tick(g.Rules.TICK)
  await settle();touch(hi,false);await settle()
  check("cancel preserves selection "+interrupt,same_selection() and not g.box_select_mode and g.touch_box_index==-1 and not g.drag_rect.visible,{"ids":g.selected,"mode":g.box_select_mode,"active":g.touch_box_active})
  if interrupt!="ended":check("cancel submits no gameplay "+interrupt,no_gameplay())
  if interrupt=="second_hud":check("second UI finger does not pause",not g.paused)
  if interrupt=="escape":check("Escape consumes mode without pausing",not g.paused)
  if interrupt=="modal":
   for child in g.ui.get_children():
    if child is ConfirmationDialog:child.canceled.emit();child.queue_free()
   await settle()
 # A second world finger can still pan, but neither release selects.
 await fresh();await start();path();touch(Vector2(650,350),true,1);var before=g.camera_focus;drag(hi,hi+Vector2(20,0));drag(Vector2(650,350),Vector2(670,350),1);touch(hi+Vector2(20,0),false);touch(Vector2(670,350),false,1);await settle()
 check("two-finger handoff pans without selection or orders",g.camera_focus!=before and same_selection() and no_gameplay() and not g.box_select_mode)
 # Reused touch ID after interruption and new mode must be usable.
 await fresh();await start();path();g._cancel_mode();touch(hi,false);await settle();await start();path();await finish()
 check("fresh gesture after canceled late release succeeds",selection_is([1,2,3,4,5]) and no_gameplay() and g.all_touch_ids.is_empty() and g.touch_points.is_empty())
 # Pause permits presentation-only selection, as required by SIM01.
 await fresh();g._toggle_pause();await start();path();await finish()
 check("paused game permits box selection without gameplay",g.paused and selection_is([1,2,3,4,5]) and no_gameplay())
 # Mode transition removes pending build/order intent rather than issuing it.
 await fresh();g._select([1]);g._start_build("house");g.build_preview_held=true;await start()
 check("box mode cancels held construction preview",g.build_mode.is_empty() and not g.build_preview_held and not is_instance_valid(g.ghost) and no_gameplay())
 g._cancel_mode();g.touch_command=true;await start();check("box mode cancels target command intent",not g.touch_command and no_gameplay())
 g._select([1]);g._start_build("house");check("new build exits box mode",not g.box_select_mode and g.build_mode=="house")
 # Ordinary touch remains pan/tap/order outside explicit mode.
 await fresh();var camera=g.camera_focus;touch(lo,true);drag(lo,hi);touch(hi,false);await settle()
 check("ordinary one-finger drag remains camera pan",g.camera_focus!=camera and same_selection() and no_gameplay())
 await fresh();var worker=g.camera.unproject_position(g._first(0,"villager").pos+Vector3(0,0.6,0));touch(worker,true);touch(worker,false);await settle()
 check("ordinary touch remains single selection",selection_is([1]) and no_gameplay())
 g.touch_command=true;touch(Vector2(650,400),true);touch(Vector2(650,400),false);await settle()
 check("ordinary targeting still submits one order",g.commands.size()==1 and g.commands[0].type=="order" and not g.touch_command)
 for mode in [false,true]:
  await fresh()
  if mode:await start()
  mouse(lo,true);motion(lo,hi);mouse(hi,false);await settle()
  check("mouse drag selection preserved mode "+str(mode),selection_is([1,2,3,4,5]) and not g.box_select_mode and no_gameplay())
 # Crossing HUD invalidates the stream even if it returns to the world.
 for pointer in ["touch","mouse"]:
  await fresh();await start();var hud=g.pause_button.get_global_rect().get_center()
  if pointer=="touch":touch(lo,true);drag(lo,hud);drag(hud,hi);touch(hi,false)
  else:mouse(lo,true);motion(lo,hud);motion(hud,hi);mouse(hi,false)
  await settle();check("HUD crossing then return cancels "+pointer,same_selection() and not g.box_select_mode and not g.drag_rect.visible and no_gameplay())
 await fresh();await start();touch(lo,true);g._home();touch(lo,false);await settle()
 check("new selection cancels old held pointer",selection_is([g._first(0,"town_center").id]) and not g.box_select_mode and no_gameplay())
 # End guard never opens mode in terminal UI.
 await fresh();g._submit("surrender");g._tick(g.Rules.TICK);g._start_box_select();check("ended match refuses new selection mode",g.game_over and not g.box_select_mode)
 var failures=rows.filter(func(r):return not r.pass).size();var report={"build":g.Rules.BUILD_ID,"game_sha256":FileAccess.get_sha256("res://scripts/game.gd"),"passed":rows.size()-failures,"failed":failures,"scope":"Synthetic routed native pointer events; viewport callback/focus notification and setup-only visibility fixture disclosed; no real phone/browser validation","rows":rows}
 FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE).store_string(JSON.stringify(report,"  "));print("TOUCH_BOX_CONTRACT ",rows.size()-failures,"/",rows.size());g.queue_free();await settle();quit(1 if failures else 0)
