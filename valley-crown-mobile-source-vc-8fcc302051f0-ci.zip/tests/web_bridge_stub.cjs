// Inert JS ownership smoke checks. No browser, DOM, engine, or network access.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');
const file = path.resolve(__dirname, '../scripts/game.gd');
const output = process.argv[2];
if (!output) throw Error('Provide an output JSON path');
const source = fs.readFileSync(file, 'utf8');
const expressions = [...source.matchAll(/JavaScriptBridge\.eval\(("[^\n]+")\)/g)].map(m => {try {return JSON.parse(m[1]);} catch {return '';}});
const install = expressions.find(x => x.includes('window.addEventListener(\'touchcancel\''));
const remove = expressions.find(x => x.includes('delete window.valleyTouchCancel;'));
if (!install || !remove) throw Error('Exact bridge source extraction failed');
const checks = [];
function check(name, ok) { checks.push({name, pass: !!ok}); if (!ok) throw Error(name); }
const listeners=[];
const window = {
 addEventListener(type, callback, capture) {listeners.push({type, callback, capture});},
 removeEventListener(type, callback, capture) {const i=listeners.findIndex(x=>x.type===type&&x.callback===callback&&x.capture===capture);if(i>=0)listeners.splice(i,1);}
};
const ctx=vm.createContext({window});
let trace=[];
window.valleyTouchCancel=()=>trace.push('cancel-intent');
vm.runInContext(install,ctx,{timeout:1000});
check('Exactly one owned touchcancel capture listener',listeners.length===1&&listeners[0].type==='touchcancel'&&listeners[0].capture===true);
check('No touchend listener intercepts ordinary release',!listeners.some(x=>x.type==='touchend'));
for (const l of [...listeners]) l.callback();
trace.push('engine-canvas-touchend');
check('Capture callback can precede engine bubble handler',JSON.stringify(trace)===JSON.stringify(['cancel-intent','engine-canvas-touchend']));
vm.runInContext(install,ctx,{timeout:1000});
check('Reinstall removes previous owned handler before adding',listeners.length===1);
let replacement=0;window.valleyTouchCancel=()=>replacement++;
listeners[0].callback();
check('Installed handler invokes current live callback',replacement===1);
delete window.valleyTouchCancel;listeners[0].callback();
check('Missing callback is a safe no-op',replacement===1);
window.valleyTouchCancel=()=>replacement++;
vm.runInContext(remove,ctx,{timeout:1000});
check('Teardown removes listener',listeners.length===0);
check('Teardown removes owned handler and callback globals',!('valleyTouchCancel' in window)&&!('valleyTouchCancelHandler' in window));
vm.runInContext(remove,ctx,{timeout:1000});
check('Repeated teardown is a no-op',listeners.length===0);
window.valleyTouchCancel=()=>replacement++;
vm.runInContext(install,ctx,{timeout:1000});listeners[0].callback();
check('Reload registration functions after teardown',listeners.length===1&&replacement===2);
vm.runInContext(remove,ctx,{timeout:1000});
const report={source:'scripts/game.gd',source_sha256:crypto.createHash('sha256').update(source).digest('hex'),checks,passed:checks.length,failed:0,scope:'Inert Node vm window/listener stub executing exact embedded JS. Does not verify real DOM ordering, JavaScriptBridge callback reentrancy, Godot cancellation or Safari behavior.'};
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
