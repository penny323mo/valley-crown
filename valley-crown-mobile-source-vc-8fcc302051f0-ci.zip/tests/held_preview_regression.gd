extends SceneTree
var game
var checks=[]
func _initialize():call_deferred("run")
func verify(name,ok,detail={}):
	checks.append({"name":name,"pass":bool(ok),"detail":detail});print("CHECK ",JSON.stringify(checks[-1]))
func settle(frames=5):
	for i in frames:await process_frame
func motion(point):
	var e=InputEventMouseMotion.new();e.position=point;e.global_position=point;root.push_input(e,true)
func click(point):
	var e=InputEventMouseButton.new();e.position=point;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;root.push_input(e,true);e.pressed=false;root.push_input(e,true)
func touch(point,pressed,index=0):
	var e=InputEventScreenTouch.new();e.position=point;e.pressed=pressed;e.index=index;root.push_input(e,true)
func begin():
	game._test_reset();game._select([game._first(0,"villager").id]);game._start_build("house")
	await settle()
func run():
	root.size=Vector2i(1180,812);game=load("res://main.tscn").instantiate();root.add_child(game);game.test_mode=true;await settle()
	var chosen=Vector3(-7.5,0,15.5);var source_point=game.camera.unproject_position(chosen)
	await begin();motion(source_point);await settle()
	verify("Hover alone never chooses or pays",not game.build_preview_held and game.build_confirm.disabled and game.commands.is_empty() and game.stocks[0].wood==200)
	click(source_point);await settle()
	verify("Desktop world click chooses only",game.build_preview_held and game.pointer_world==chosen and not game.build_confirm.disabled and game.commands.is_empty() and game.stocks[0].wood==200)
	var target=game.build_confirm.get_global_rect().get_center();var stable=true
	for step in range(1,41):
		motion(source_point.lerp(target,step/40.0));await process_frame;stable=stable and game.pointer_world==chosen
	verify("Continuous traversal holds explicitly chosen site",stable)
	click(target);await settle()
	verify("Confirm emits exactly one unchanged build command",game.commands.size()==1 and game.commands[0].type=="build" and game.commands[0].position==chosen and game.commands[0].kind=="house" and game.build_mode.is_empty() and game.stocks[0].wood==200)
	game._tick(game.Rules.TICK)
	verify("Normal authoritative tick charges once",game.stocks[0].wood==150 and game._count(0,"house")==1 and game.economy.audit().ok)
	game._confirm_build();game._tick(game.Rules.TICK)
	verify("Repeated confirmation does not pay twice",game.stocks[0].wood==150 and game._count(0,"house")==1)
	await begin();click(source_point);await settle()
	var invalid=game._first(0,"town_center").pos;var invalid_point=game.camera.unproject_position(invalid);click(invalid_point);await settle()
	verify("Explicit reselect changes held site even if invalid",game.pointer_world==game._point(game._cell(invalid)) and game.build_preview_held and game.build_confirm.disabled)
	motion(source_point);await settle();game._confirm_build()
	verify("Invalid site never falls back to a last-valid location",game.pointer_world==game._point(game._cell(invalid)) and game.commands.is_empty() and game.stocks[0].wood==200)
	click(source_point);await settle();verify("Explicit world reselect can choose valid site",game.pointer_world==chosen and not game.build_confirm.disabled)
	game._cancel_mode();verify("Cancel clears held intent without payment",not game.build_preview_held and game.build_mode.is_empty() and game.commands.is_empty() and game.stocks[0].wood==200)
	await begin();touch(source_point,true);touch(source_point,false);await settle()
	verify("Touch release only chooses preview",game.build_preview_held and game.pointer_world==chosen and game.commands.is_empty() and game.stocks[0].wood==200)
	var first_point=game.camera.unproject_position(Vector3(-8.5,0,15.5));touch(first_point,true)
	var drag=InputEventScreenDrag.new();drag.index=0;drag.position=source_point;drag.relative=source_point-first_point;root.push_input(drag,true);touch(source_point,false);await settle()
	verify("Touch drag/release remains preview-only",game.build_preview_held and game.pointer_world==chosen and game.commands.is_empty() and game.stocks[0].wood==200)
	target=game.build_confirm.get_global_rect().get_center();touch(target,true);touch(target,false);await settle()
	verify("Touch Confirm emits chosen-site command",game.commands.size()==1 and game.commands[0].position==chosen and game.commands[0].type=="build",{"commands":game.commands,"pointer":str(game.pointer_world),"held":game.build_preview_held,"gesture":game.touch_gesture,"touches":game.touch_points,"all_touches":game.all_touch_ids,"disabled":game.build_confirm.disabled if is_instance_valid(game.build_confirm) else false})
	await begin();click(source_point);await settle();game._toggle_pause()
	verify("Pause cancels held preview",game.paused and not game.build_preview_held and game.build_mode.is_empty() and game.commands.is_empty())
	await begin();click(source_point);await settle()
	touch(source_point,true,0);touch(game.pause_button.get_global_rect().get_center(),true,1);game._confirm_build()
	verify("Two-finger overlap cannot confirm",game.commands.is_empty())
	touch(source_point,false,0);touch(game.pause_button.get_global_rect().get_center(),false,1);await settle()
	# Raw ScreenTouch button safety with mouse emulation disabled.
	game._test_reset();game._home();await settle()
	var pause_point=game.pause_button.get_global_rect().get_center();touch(pause_point,true);touch(pause_point,false);await settle()
	verify("Raw touch Pause activates once",game.paused)
	touch(pause_point,false);await settle();verify("Duplicate raw touch release never reactivates",game.paused and game.gui_touch_press.is_empty())
	touch(pause_point,true);touch(pause_point,false);await settle();verify("Raw touch Continue activates once",not game.paused)
	touch(pause_point,true)
	var cancel_event=InputEventScreenTouch.new();cancel_event.position=pause_point;cancel_event.index=0;cancel_event.pressed=false;cancel_event.canceled=true;root.push_input(cancel_event,true);await settle()
	verify("Canceled UI touch never activates",not game.paused and game.gui_touch_press.is_empty())
	touch(pause_point,true);var ui_drag=InputEventScreenDrag.new();ui_drag.position=pause_point+Vector2(20,0);ui_drag.relative=Vector2(20,0);ui_drag.index=0;root.push_input(ui_drag,true);touch(pause_point+Vector2(20,0),false);await settle()
	verify("Dragged UI touch never activates",not game.paused and game.gui_touch_press.is_empty())
	touch(pause_point,true,0);touch(Vector2(600,300),true,1);touch(pause_point,false,0);touch(Vector2(600,300),false,1);await settle()
	verify("Second finger cancels UI activation",not game.paused and game.gui_touch_press.is_empty() and game.commands.is_empty())
	var menu_point=game.compact_menu_button.get_global_rect().get_center();touch(menu_point,true);touch(menu_point,false);await settle();verify("Raw touch menu activates once",game.compact_menu.visible)
	touch(Vector2(400,300),true);touch(Vector2(400,300),false);await settle();verify("Raw touch menu dismissal consumes gesture",not game.compact_menu.visible and game.commands.is_empty())
	game._cancel_mode();game._select([game._first(0,"villager").id]);game.touch_command=true
	var world_point=Vector2(600,300);touch(world_point,true)
	var world_cancel=InputEventScreenTouch.new();world_cancel.position=world_point;world_cancel.index=0;world_cancel.pressed=false;world_cancel.canceled=true;root.push_input(world_cancel,true);await settle()
	verify("System-canceled world touch never becomes an order",game.commands.is_empty() and not game.touch_command and game.touch_points.is_empty())
	var failed=checks.filter(func(c):return not c.pass).size();var report={"source_sha256":FileAccess.get_sha256("res://scripts/game.gd"),"spec":"UX01 desktop preview then Confirm/Cancel; touch release is not an order","scope":"Actual Godot event sequences including40 mouse-motion steps. Native synthetic events do not establish browser or physical-device behavior.","passed":checks.size()-failed,"failed":failed,"checks":checks};FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE).store_string(JSON.stringify(report,"  "));print("HELD_BUILD_PREVIEW ",checks.size()-failed,"/",checks.size());quit(0 if failed==0 else 1)
