extends SceneTree
# Regression for reused-index deferred cleanup; synthetic routing, not real touch.
var g
var rows=[]
var lo=Vector2(270,400)
var hi=Vector2(410,500)
func _initialize():call_deferred("run")
func check(name,ok,detail={}):rows.append({"name":name,"pass":bool(ok),"detail":detail});print("EPOCH ",name," ",ok)
func settle():
 for i in 4:await process_frame
func touch(point,down,index=31,canceled=false):
 var e=InputEventScreenTouch.new();e.position=point;e.pressed=down;e.index=index;e.canceled=canceled;root.push_input(e,true)
func drag(a,b,index=31):
 var e=InputEventScreenDrag.new();e.position=b;e.relative=b-a;e.index=index;root.push_input(e,true)
func find_button(node,label):
 if node is Button and node.text==label:return node
 for child in node.get_children():
  var b=find_button(child,label)
  if b!=null:return b
 return null
func fresh():
 g._test_reset();g._cancel_mode();g.camera_focus=Vector3(-7,0,5);g.camera_zoom=30;g._camera_update();g._select([6]);g._start_box_select();await settle()
func clean():return g.touch_points.is_empty() and g.all_touch_ids.is_empty() and g.gui_touch_press.is_empty() and g.touch_press_epochs.is_empty()
func run():
 root.size=Vector2i(1180,812);g=load("res://main.tscn").instantiate();root.add_child(g);g.test_mode=true;g.set_process(false);await settle()
 for duplicate in [false,true]:
  await fresh();touch(lo,true);touch(lo,false)
  if duplicate:touch(lo,false)
  touch(lo,true);var epoch=g.touch_press_epochs.get(31,-1);await settle()
  check("fresh same-ID world press survives old cleanup "+str(duplicate),g.box_select_mode and g.touch_box_index==31 and g.touch_points.has(31) and g.all_touch_ids.has(31) and g.touch_press_epochs.get(31,-1)==epoch)
  drag(lo,hi);touch(hi,false);await settle()
  check("same-ID fresh drag selects once "+str(duplicate),g.selected==[1,2,3,4,5] and not g.box_select_mode and g.commands.is_empty() and clean())
 # The old world release must not erase a new cancel-button press either.
 for duplicate in [false,true]:
  await fresh();var b=find_button(g.actions,"取消框選");var point=b.get_global_rect().get_center()
  touch(lo,true);touch(lo,false)
  if duplicate:touch(lo,false)
  touch(point,true);await settle()
  check("world-to-GUI same-ID press survives cleanup "+str(duplicate),g.box_select_mode and g.gui_touch_press.has(31) and g.all_touch_ids==[31])
  touch(point,false);await settle();check("fresh GUI cancel activates once "+str(duplicate),not g.box_select_mode and g.selected==[6] and g.commands.is_empty() and clean())
 # A canceled stream invalidates its epoch, with a fresh same-ID press accepted.
 await fresh();touch(lo,true);var old=g.touch_press_epochs[31];g._cancel_mode();touch(hi,false);g._start_box_select();touch(lo,true);var epoch=g.touch_press_epochs[31];await settle();drag(lo,hi);touch(hi,false);await settle()
 check("cancellation never recycles touch generation",epoch>old and g.selected==[1,2,3,4,5] and clean())
 # Rapid complete cycles before any idle flush must retain only the final press.
 await fresh()
 for i in 8:touch(lo,true);touch(lo,false)
 touch(lo,true);await settle();check("many queued stale cleanups preserve latest press",g.touch_points.has(31) and g.touch_box_index==31 and g.box_select_mode)
 drag(lo,hi);touch(hi,false);await settle();check("many stale cleanups cause no repeated selection or command",g.selected==[1,2,3,4,5] and clean() and g.commands.is_empty())
 # No-mode world pan and standard GUI controls use the same lifetime guard.
 await fresh();g._cancel_mode();touch(lo,true);touch(lo,false);touch(lo,true);await settle();var camera=g.camera_focus;drag(lo,hi);touch(hi,false);await settle()
 check("ordinary world same-ID pan survives cleanup",g.camera_focus!=camera and clean() and g.commands.is_empty())
 await fresh();g._cancel_mode();var point=g.pause_button.get_global_rect().get_center();touch(lo,true);touch(lo,false);touch(point,true);await settle();touch(point,false);await settle()
 check("ordinary GUI same-ID pause survives cleanup",g.paused and clean() and g.commands.is_empty())
 var failed=rows.filter(func(r):return not r.pass).size();FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE).store_string(JSON.stringify({"build":g.Rules.BUILD_ID,"game_sha256":FileAccess.get_sha256("res://scripts/game.gd"),"passed":rows.size()-failed,"failed":failed,"rows":rows},"  "));print("TOUCH_EPOCH ",rows.size()-failed,"/",rows.size());g.queue_free();await settle();quit(1 if failed else 0)
