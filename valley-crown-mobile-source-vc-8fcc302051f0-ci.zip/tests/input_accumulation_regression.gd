extends SceneTree
# Mode-scoped accumulation ownership and coalesced crossing regression.
# Raw native synthetic events, not physical phone or desktop mouse evidence.
var g
var rows=[]
const A=Vector2(260,395)
const B=Vector2(260,755)
const C=Vector2(410,505)
func _initialize():call_deferred("run")
func check(name,ok,detail={}):rows.append({"name":name,"pass":bool(ok),"detail":detail});print("ACCUMULATION ",name," ",ok)
func settle():
 for i in 4:await process_frame
func event(e,flush=true):
 Input.parse_input_event(e)
 if flush:Input.flush_buffered_events()
func mouse(point,down):
 var e=InputEventMouseButton.new();e.position=point;e.global_position=point;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=down;event(e)
func motion(point,relative,flush=false):
 var e=InputEventMouseMotion.new();e.position=point;e.global_position=point;e.relative=relative;e.button_mask=MOUSE_BUTTON_MASK_LEFT;event(e,flush)
func touch(point,down,index=31,canceled=false):
 var e=InputEventScreenTouch.new();e.position=point;e.index=index;e.pressed=down;e.canceled=canceled;event(e)
func drag(point,relative,flush=false,index=31):
 var e=InputEventScreenDrag.new();e.position=point;e.index=index;e.relative=relative;event(e,flush)
func key(code):
 var e=InputEventKey.new();e.physical_keycode=code;e.keycode=code;e.pressed=true;event(e);e=e.duplicate();e.pressed=false;event(e)
func fresh(prior):
 g._test_reset();g._cancel_mode();g.compact_menu.hide();g.compact_menu_dismiss.hide();g.camera_focus=Vector3(-7,0,5);g.camera_zoom=30;g._camera_update();g._select([6]);Input.use_accumulated_input=prior;g._start_box_select();await settle()
func unit_ids():return [1,2,3,4,5]
func authority():return [g.tick_count,g.command_sequence,g.commands.duplicate(true),g.economy.snapshot(),g._population(0),g._capacity(0)]
func run():
 root.size=Vector2i(1180,812);g=load("res://main.tscn").instantiate();root.add_child(g);g.test_mode=true;g.set_process(false);await settle()
 for prior in [true,false]:
  await fresh(prior);check("entry owns raw input previous="+str(prior),g.box_select_mode and g.box_input_accumulation_owned and not Input.use_accumulated_input and g.box_previous_input_accumulation==prior)
  g._start_box_select();check("reentry retains original setting previous="+str(prior),g.box_input_accumulation_owned and not Input.use_accumulated_input and g.box_previous_input_accumulation==prior)
  touch(A,true);touch(A,false);await settle();check("short tap retains scoped ownership previous="+str(prior),g.box_select_mode and g.box_input_accumulation_owned and not Input.use_accumulated_input)
  for pointer in ["mouse","touch"]:
   await fresh(prior);var before=authority();var camera=g.camera_focus
   if pointer=="mouse":mouse(A,true);motion(B,B-A);motion(C,C-B);mouse(C,false)
   else:touch(A,true);drag(B,B-A);drag(C,C-B);touch(C,false)
   await settle();check("batched HUD excursion cancels "+pointer+" previous="+str(prior),g.selected==[6] and not g.box_select_mode and not g.drag_rect.visible and Input.use_accumulated_input==prior and not g.box_input_accumulation_owned)
   check("batched excursion preserves authority "+pointer+" previous="+str(prior),authority()==before and g.camera_focus==camera)
   await fresh(prior)
   if pointer=="mouse":mouse(A,true);motion(Vector2(290,425),Vector2(30,30));motion(C,C-Vector2(290,425));mouse(C,false)
   else:touch(A,true);drag(Vector2(290,425),Vector2(30,30));drag(C,C-Vector2(290,425));touch(C,false)
   await settle();check("batched world rectangle completes "+pointer+" previous="+str(prior),g.selected==unit_ids() and not g.box_select_mode and Input.use_accumulated_input==prior and not g.box_input_accumulation_owned)
  for reason in ["cancel","right","escape","menu","pause","viewport_callback","focus","background","modal","system_cancel","second_finger","external_select","build","pointer_clear","terminal"]:
   await fresh(prior)
   if reason=="build":g._select([1]);g._start_box_select()
   touch(A,true)
   match reason:
    "cancel":g._cancel_mode()
    "right":
     var e=InputEventMouseButton.new();e.position=C;e.button_index=MOUSE_BUTTON_RIGHT;e.pressed=true;event(e);e=e.duplicate();e.pressed=false;event(e)
    "escape":key(KEY_ESCAPE)
    "menu":g._toggle_compact_menu()
    "pause":g._toggle_pause()
    "viewport_callback":g._on_viewport_size_changed()
    "focus":g.test_mode=false;g._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT);g.test_mode=true
    "background":g.test_mode=false;g._notification(Node.NOTIFICATION_APPLICATION_PAUSED);g.test_mode=true
    "modal":g._confirm_surrender()
    "system_cancel":touch(C,false,31,true)
    "second_finger":touch(Vector2(650,350),true,32);touch(Vector2(650,350),false,32)
    "external_select":g._home()
    "build":g._start_build("house")
    "pointer_clear":g._cancel_pointer_streams()
    "terminal":g._submit("surrender");g._tick(g.Rules.TICK)
   touch(C,false);await settle()
   check("restore on "+reason+" previous="+str(prior),not g.box_select_mode and not g.box_input_accumulation_owned and Input.use_accumulated_input==prior)
   if reason=="modal":
    for child in g.ui.get_children():
     if child is ConfirmationDialog:child.canceled.emit();child.queue_free()
    await settle()
  await fresh(prior);g.queue_free();await settle();check("scene teardown restores previous="+str(prior),Input.use_accumulated_input==prior)
  g=load("res://main.tscn").instantiate();root.add_child(g);g.test_mode=true;g.set_process(false);await settle();check("new scene preserves previous normal setting="+str(prior),Input.use_accumulated_input==prior and not g.box_input_accumulation_owned)
 # After leaving the mode, ordinary engine coalescing retains the prior policy.
 await fresh(true);g._cancel_mode();mouse(A,true);motion(B,B-A);motion(C,C-B);mouse(C,false);await settle()
 check("normal mouse still uses default accumulated input",Input.use_accumulated_input and g.selected==unit_ids() and g.commands.is_empty())
 var failed=rows.filter(func(r):return not r.pass).size();FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE).store_string(JSON.stringify({"build":g.Rules.BUILD_ID,"game_sha256":FileAccess.get_sha256("res://scripts/game.gd"),"passed":rows.size()-failed,"failed":failed,"rows":rows,"scope":"Headless native synthetic batched mouse/ScreenDrag and lifecycle tests; no real desktop/phone/browser acceptance"},"  "));print("ACCUMULATION_CONTRACT ",rows.size()-failed,"/",rows.size());g.queue_free();await settle();Input.use_accumulated_input=true;quit(1 if failed else 0)
