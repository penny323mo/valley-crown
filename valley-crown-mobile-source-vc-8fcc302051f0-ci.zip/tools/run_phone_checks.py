#!/usr/bin/env python3
"""Portable native test runner. Import resources with the pinned editor first."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
ENGINE_VERSION = '4.6.3.stable.official.7d41c59c4'
ENGINE_SHA256 = 'f64d4ed19fc9df9440321653fcc80df8c6e365ba7b6de0a29e2cfa9fa71bfeb3'
TESTS = [
    'web_bridge_stub',
    'canopy_geometry',
    'held_preview_regression',
    'touch_box_regression',
    'touch_epoch_regression',
    'input_accumulation_regression',
    'phone_input_edges',
    'phone_core_flow',
]

def verify_source():
    manifest = json.loads((ROOT/'tools/source_manifest.json').read_text())
    bad = []
    for name, expected in manifest['source_sha256'].items():
        path = ROOT/name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            bad.append(name)
    if bad:
        raise RuntimeError('Runtime source identity mismatch: '+', '.join(bad))
    return manifest

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--godot', default='godot')
    parser.add_argument('--output', type=Path, default=ROOT/'artifacts/tests')
    parser.add_argument('--test', choices=TESTS, action='append')
    parser.add_argument('--timeout', type=int, default=240)
    args = parser.parse_args()
    manifest = verify_source()
    test_manifest = json.loads((ROOT/'tools/test_manifest.json').read_text())
    if test_manifest['build'] != manifest['build']:
        raise RuntimeError('Test/runtime build identity mismatch')
    executable = shutil.which(args.godot)
    if not executable:
        raise RuntimeError('Godot executable not found')
    executable = str(Path(executable).resolve())
    engine_sha = hashlib.sha256(Path(executable).read_bytes()).hexdigest()
    if engine_sha != ENGINE_SHA256:
        raise RuntimeError('Use the pinned official Linux x86_64 Godot binary')
    version = subprocess.check_output([executable,'--version'],text=True).strip()
    if version != ENGINE_VERSION:
        raise RuntimeError('Unexpected Godot version: '+version)
    args.output.mkdir(parents=True, exist_ok=True)
    records = []
    for name in args.test or TESTS:
        script = ROOT/'tests'/(name+('.cjs' if name=='web_bridge_stub' else '.gd'))
        if not script.is_file():
            raise RuntimeError('Missing required test: '+str(script.relative_to(ROOT)))
        relative_script = script.relative_to(ROOT).as_posix()
        expected_test_sha = test_manifest['source_sha256'].get(relative_script)
        if hashlib.sha256(script.read_bytes()).hexdigest() != expected_test_sha:
            raise RuntimeError('Test script identity mismatch: '+relative_script)
        output = args.output/f'{name}.json'
        log = args.output/f'{name}.log'
        if output.exists() or log.exists():
            raise RuntimeError('Refusing to overwrite test evidence: '+name)
        print('START '+name+' build='+manifest['build'],flush=True)
        started = time.monotonic()
        if name == 'web_bridge_stub':
            node = shutil.which('node')
            if not node:
                raise RuntimeError('Node.js is required for the inert bridge stub')
            command = [node,str(script),str(output.resolve())]
        else:
            command = [executable,'--headless','--path',str(ROOT),'--script','res://tests/'+script.name,'--',str(output.resolve())]
        try:
            with log.open('x') as stream:
                result = subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=args.timeout,check=False)
            code = result.returncode
            stopped = None
        except subprocess.TimeoutExpired:
            code = None
            stopped = 'timeout'
        text = log.read_text(errors='replace')
        errors = [line for line in text.splitlines() if any(marker in line for marker in ['ERROR:', 'SCRIPT ERROR:', 'WARNING:'])]
        report = json.loads(output.read_text()) if output.exists() else None
        passed = code == 0 and stopped is None and not errors and report is not None and report.get('failed',1) == 0
        row = {'test':name,'kind':'inert_js' if name=='web_bridge_stub' else 'native_godot','build':manifest['build'],'engine_sha256':engine_sha,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'exit_code':code,'stop_reason':stopped,'seconds':round(time.monotonic()-started,3),'passed':passed,'errors':errors,'report_present':report is not None}
        records.append(row)
        (args.output/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
        print(json.dumps(row),flush=True)
        if not passed:
            print(text[-24000:],flush=True)
            return 1
        verify_source()
    print('All requested native suites completed. Browser and physical-device validation are separate.',flush=True)
    return 0

if __name__ == '__main__':
    sys.exit(main())
